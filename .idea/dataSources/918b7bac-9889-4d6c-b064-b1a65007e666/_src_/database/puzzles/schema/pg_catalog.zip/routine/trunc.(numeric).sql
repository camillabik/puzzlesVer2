create function trunc(numeric) returns numeric
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.trunc($1,0)
$$;
