CREATE VIEW information_schema_catalog_name AS SELECT (current_database())::information_schema.sql_identifier AS catalog_name;
